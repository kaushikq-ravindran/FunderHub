#FunderHub
This is an android application that allows students to start campaigns for their school/college projects and the other users can donate to the campaign.

<h2> Screenshots </h2>

<img src = "/1.png" width = "200">   <img src = "/2.png" width = "200">   <img src = "/3.png" width = "200">   <img src = "/4.png" width = "200">



