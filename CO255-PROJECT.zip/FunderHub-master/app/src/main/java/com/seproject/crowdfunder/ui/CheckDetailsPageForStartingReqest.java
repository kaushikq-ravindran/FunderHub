package com.seproject.crowdfunder.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.seproject.crowdfunder.R;
/**  Mahesh Babu - 17CO216 */
public class CheckDetailsPageForStartingReqest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_details_page_for_starting_request);
    }
}
