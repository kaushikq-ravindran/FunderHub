package com.seproject.crowdfunder.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.seproject.crowdfunder.R;
/** Mahesh  - 17CO216 */
public class StartARequestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_arequest);
    }

    public void StartAProject(View view) {
        startActivity(new Intent(this,Choose.class));
        finish();
    }
}
