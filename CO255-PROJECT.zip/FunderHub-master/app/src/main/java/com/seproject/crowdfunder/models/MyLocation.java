package com.seproject.crowdfunder.models;
/**   Kaushiq - 17CO131 */
public class MyLocation {
    float lat, lon;

    public MyLocation(float lat, float lon) {
        this.lat = lat;
        this.lon = lon;
    }

    public float getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public float getLon() {
        return lon;
    }

    public void setLon(float lon) {
        this.lon = lon;
    }
}
