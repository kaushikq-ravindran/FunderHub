package com.seproject.crowdfunder.ui;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.seproject.crowdfunder.R;
/**  adarsh 17CO204 */
public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText mEmailView;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        mEmailView = findViewById(R.id.registered_emailid);
    }


    private void attemptLogin() {

        // Reset errors.
        mEmailView.setError(null);

        // Store values at the time of the login attempt.
        String email = mEmailView.getText().toString();

        boolean cancel = false;
        View focusView = null;



        // Check for a valid email address.
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            firebaseAuth= FirebaseAuth.getInstance();

                String useremail=mEmailView.getText().toString();
                Log.d("ForgotPassword: ","password");
                if(useremail.equals(""))
                {
                    Toast.makeText(ForgotPasswordActivity.this,"enter registered email ID", Toast.LENGTH_SHORT).show();
                }
                else{
                    firebaseAuth.sendPasswordResetEmail(useremail)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {
                                    Toast.makeText(ForgotPasswordActivity.this,"password reset email sent",Toast.LENGTH_SHORT).show();
                                    finish();
                                    startActivity(new Intent(ForgotPasswordActivity.this,LoginActivity.class));
                                    // startActivity(new Intent(crowdfunding.this,MainActivity.class));
                                }
                                else
                                {
                                    Toast.makeText(ForgotPasswordActivity.this,"error in sending password reset email",Toast.LENGTH_SHORT).show();
                                }
                            }});
                }
            }
        }


    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 8;
    }

    public void asdf(View view) {
        attemptLogin();
    }
}
